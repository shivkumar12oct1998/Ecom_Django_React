import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useCart } from '../components/CartContext';
import './Product.css'; // Import the new CSS file

function Product() {
  const location = useLocation();
  const navigate = useNavigate();
  const { addToCart, checkStock, products, updateStock } = useCart();

  const { product } = location.state; // Get the passed product state
  const [stockcount, setStockCount] = useState(product.stockcount); // Local stock count state

  // Ensure stock count is updated from global context (CartContext)
  useEffect(() => {
    const productInContext = products.find((prod) => prod.id === product.id);
    if (productInContext) {
      setStockCount(productInContext.stockcount); // Sync local stock with global context
    }
  }, [products, product.id]);

  // Check if the product is in stock before adding to cart
  const handleAddToCart = () => {
    // First, check the stock in the global context
    if (checkStock(product.id)) {
      // Add the product to the cart
      addToCart(product);

      // Decrease the stock count by 1 in the global state and update local state
      const updatedStock = stockcount - 1;
      setStockCount(updatedStock); // Update local stock state

      // Update stock globally in context
      updateStock(product.id, updatedStock);

      alert('Product added to cart');
      navigate('/cart'); // Navigate to the cart page
    } else {
      alert('Product is out of stock');
    }
  };

  return (
    <div className="product-container">
      <div className="product-header">
        <h1>Product Details</h1>
      </div>

      <div className="product-content">
        {/* Product Details Section */}
        <div className="product-details">
          <div className="product-image">
            <img src={product.image} alt={product.productname} className="product-img" />
          </div>
          <div className="product-info">
            <h2>{product.productname}</h2>
            <h3 className="product-category">{product.productcategory}</h3>
            <p className="product-description">ProductInfo: {product.productinfo}</p>
            <div className="product-price">
              <h4>Price: <span className="price">${product.price}</span></h4>
            </div>

            {/* Display current stock */}
            <p className="product-stock">Stock: {stockcount} available</p>
          </div>
        </div>

        {/* Add to Cart Column */}
        <div className="add-to-cart-column">
          <button 
            className="add-to-cart-btn"  
            onClick={handleAddToCart}
            disabled={stockcount === 0} // Disable the button if stock is 0
          >
            {stockcount === 0 ? 'Out of Stock' : 'Add to Cart'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default Product;
