import React, { useEffect, useState } from 'react';
import { Container, Nav, Navbar, Row, Col, Card } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Home.css'; // Import the CSS file for styling
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHouse, faRightToBracket, faCartShopping } from '@fortawesome/free-solid-svg-icons'

function Home() {
    const [products, setProducts] = useState([]);
    const navigate = useNavigate(); // Initialize the useNavigate hook

    useEffect(() => {
        async function fetchProducts() {
            const { data } = await axios.get('/getproducts/');
            setProducts(data);
        }
        fetchProducts();
    }, []);

    // Function to handle the image click and navigate to Product page
    const handleImageClick = (product) => {
        navigate(`/product/${product.id}`, { state: { product } });
    };

    return (
        <>
            <Navbar expand="lg" className="navbar">
                <Container>
                    <Navbar.Brand href="#home" className="navbar-brand">
                        Ecommerce Website
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            <Link to="/">
                                <Nav.Link className="nav-link mx-3"><FontAwesomeIcon icon={faHouse} />Home</Nav.Link>
                            </Link>
                            <Link to="/login">
                                <Nav.Link className="nav-link mx-3"><FontAwesomeIcon icon={faRightToBracket} />Login</Nav.Link>
                            </Link>
                            <Link to="/">
                                <Nav.Link className="nav-link mx-3"><FontAwesomeIcon icon={faCartShopping} />Cart</Nav.Link>
                            </Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            <Container className="product-container">
                <Row>
                    {products.map((product) => (
                        <Col key={product.id} sm={12} md={6} lg={4}>
                            <Card className="product-card">
                                <div className="product-image-container">
                                    <img
                                        src={product.image}
                                        className="product-image"
                                        alt={product.productname}
                                        onClick={() => handleImageClick(product)}
                                    />
                                </div>
                                <div className="product-info">
                                    <h2 className="product-name">{product.productname}</h2>
                                    <p className="product-category">{product.productcategory}</p>
                                    <p className="product-price">${product.price}</p>
                                </div>
                            </Card>
                            <br /><br /><br />
                        </Col>
                    ))}
                </Row>
            </Container>

            {/* Footer Section */}
            <footer className="footer">
                <Container>
                    <Row>
                        <Col className="text-center py-3">
                            &copy; {new Date().getFullYear()} Ecommerce Website. All Rights Reserved.
                        </Col>
                    </Row>
                </Container>
            </footer>
        </>
    );
}

export default Home;
