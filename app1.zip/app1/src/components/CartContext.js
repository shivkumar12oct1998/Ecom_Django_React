import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children, initialProducts = [] }) => {
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState(initialProducts); // Using the products passed in as a prop

  // Optionally, you could fetch products from an API if no `initialProducts` are passed.
  useEffect(() => {
    if (initialProducts.length === 0) {
      // Fetch products from an API or other source if no initial products are provided
      const fetchProducts = async () => {
        const response = await fetch('/getproducts'); // Example API endpoint
        const data = await response.json();
        setProducts(data);
      };
      fetchProducts();
    }
  }, [initialProducts]);

  const addToCart = (product) => {
    // Check stock before adding to the cart
    if (product.stockcount > 0) {
      setCart((prevCart) => {
        const existingProduct = prevCart.find((item) => item.id === product._id);
        if (existingProduct) {
          return prevCart.map((item) =>
            item.id === product._id
              ? { ...item, quantity: item.quantity + 1 }
              : item
          );
        } else {
          return [...prevCart, { ...product, quantity: 1 }];
        }
      });
      
      // Update the stock after adding the product to the cart
      updateStock(product._id, product.stockcount - 1);
    } else {
      alert('Product is out of stock');
    }
  };

  const updateStock = (productId, newStock) => {
    setProducts((prevProducts) =>
      prevProducts.map((product) =>
        product._id === productId ? { ...product, stockcount: newStock } : product
      )
    );
  };

  const checkStock = (productId) => {
    const product = products.find((p) => p.id === productId);
    return product ? product.stockcount > 0 : false;
  };

  const clearCart = () => setCart([]);

  return (
    <CartContext.Provider value={{ cart, products, addToCart, checkStock, clearCart, updateStock }}>
      {children}
    </CartContext.Provider>
  );
};
