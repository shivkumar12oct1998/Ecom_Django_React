import React, { useState } from 'react';
import { useCart } from '../components/CartContext';
import { useNavigate } from 'react-router-dom';

function Cart() {
  const { cart, clearCart } = useCart();
  const navigate = useNavigate(); // To navigate to the home page
  const [isPaymentProcessed, setIsPaymentProcessed] = useState(false);

  // Calculate the total price of all items in the cart
  const totalPrice = cart.reduce((total, item) => total + item.price * item.quantity, 0);

  const handlePayment = () => {
    // Implement your payment logic here
    alert('Payment Successful');
    clearCart(); // Clear the cart after payment

    // Set a flag to show that payment was processed and the cart is empty
    setIsPaymentProcessed(true);
  };

  const handleAddMoreProducts = () => {
    // Navigate back to the home page to add more products
    navigate('/');
  };

  const handleGoToHome = () => {
    // Navigate to the home page
    navigate('/');
  };

  const cartStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '20px',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
    width: '80%',
    maxWidth: '1000px',
    margin: 'auto',
  };

  const cartTitleStyle = {
    fontSize: '2rem',
    fontWeight: 'bold',
    marginBottom: '20px',
    color: '#333',
  };

  const cartEmptyStyle = {
    fontSize: '1.2rem',
    color: '#777',
    textAlign: 'center',
  };

  const cartItemStyle = {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: '15px',
    padding: '10px',
    backgroundColor: '#fff',
    borderRadius: '8px',
    boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
    width: '100%',
    maxWidth: '900px',
  };

  const cartImageStyle = {
    width: '80px',
    height: '80px',
    objectFit: 'cover',
    marginRight: '15px',
    borderRadius: '8px',
  };

  const cartDetailsStyle = {
    flex: '1',
  };

  const cartPriceStyle = {
    fontSize: '1.2rem',
    fontWeight: 'bold',
    color: '#e74c3c',
  };

  const buttonStyle = {
    padding: '10px 20px',
    backgroundColor: '#2ecc71',
    color: '#fff',
    fontSize: '1.1rem',
    fontWeight: 'bold',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    marginTop: '20px',
    transition: 'background-color 0.3s',
  };

  const buttonHoverStyle = {
    backgroundColor: '#27ae60',
  };

  return (
    <div style={cartStyle}>
      <h1 style={cartTitleStyle}>Your Cart</h1>
      {cart.length === 0 || isPaymentProcessed ? (
        <div>
          <p style={cartEmptyStyle}>Your cart is empty!</p>
          <button
            style={buttonStyle}
            onMouseOver={(e) => (e.target.style.backgroundColor = buttonHoverStyle.backgroundColor)}
            onMouseOut={(e) => (e.target.style.backgroundColor = buttonStyle.backgroundColor)}
            onClick={handleGoToHome}
          >
            Go to Home
          </button>
        </div>
      ) : (
        <div>
          {/* Map through the cart items */}
          {cart.map((item) => (
            <div key={item.id} style={cartItemStyle}>
              <img
                src={item.image}
                alt={item.productname}
                style={cartImageStyle}
              />
              <div style={cartDetailsStyle}>
                <h2>{item.productname}</h2>
                <p>{item.productcategory}</p>
                <p>Quantity: {item.quantity}</p>
              </div>
              <p style={cartPriceStyle}>${(item.price * item.quantity).toFixed(2)}</p>
            </div>
          ))}
          {/* Display the total price */}
          <div>
            <h3>Total Payment: ${totalPrice.toFixed(2)}</h3>
          </div>
          <div>
            <button
              style={buttonStyle}
              onMouseOver={(e) => (e.target.style.backgroundColor = buttonHoverStyle.backgroundColor)}
              onMouseOut={(e) => (e.target.style.backgroundColor = buttonStyle.backgroundColor)}
              onClick={handleAddMoreProducts}
            >
              Add More Products
            </button>
          </div>
          <div>
            <button
              style={buttonStyle}
              onMouseOver={(e) => (e.target.style.backgroundColor = buttonHoverStyle.backgroundColor)}
              onMouseOut={(e) => (e.target.style.backgroundColor = buttonStyle.backgroundColor)}
              onClick={handlePayment}
            >
              Proceed to Payment
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Cart;
