
import './App.css';
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom'; // Using HashRouter for routing
import Login from './components/login';
import Cart from './components/cart';
import Home from './components/home';
import Product from './components/Product';
import { CartProvider } from './components/CartContext';


function App() {
  return (
    <CartProvider> 
    <Router> 
      
      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route exact path="/login" element={<Login />} />
        <Route exact path="/cart" element={<Cart />} />
        <Route path="/product/:id" element={<Product />} />
        
      </Routes> 
    </Router>
    </CartProvider>
  );
}

export default App;